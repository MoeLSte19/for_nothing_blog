"""Extract page images from the scanned textbook PDF into a temp folder.

Each page is a DCTDecode (JPEG) XObject, so the bytes can be written out as-is.
Run with no arguments; writes to scripts/_pages/.
"""
import os
import re

VAULT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(VAULT, "04-资料库")
OUT = os.path.join(VAULT, "scripts", "_pages")
os.makedirs(OUT, exist_ok=True)

candidates = []
for dirpath, _d, filenames in os.walk(LIB):
    for fn in filenames:
        if fn.lower().endswith(".pdf"):
            candidates.append(os.path.join(dirpath, fn))
target = max(candidates, key=os.path.getsize)
raw = open(target, "rb").read()
print(f"src: {os.path.basename(target)}  {len(raw):,} bytes")

# Walk objects in file order; every /Subtype /Image with /DCTDecode holds JPEG bytes.
obj_re = re.compile(rb"(\d+)\s+0\s+obj(.*?)endobj", re.S)
page_re = re.compile(rb"/Contents\s+(\d+)\s+0\s+R")
img_obj_re = re.compile(rb"/Im0\s+(\d+)\s+0\s+R")

objects = {}
for m in obj_re.finditer(raw):
    objects[int(m.group(1))] = m.group(2)

# map page order -> image object via /Contents -> page dict -> /Im0
order = []
for num in sorted(objects):
    body = objects[num]
    if b"/Type /Page" in body or b"/Type/Page" in body:
        if b"/Pages" in body:
            continue
        m = img_obj_re.search(body)
        if m:
            order.append(int(m.group(1)))

print(f"pages found: {len(order)}")

saved = 0
for idx, img_num in enumerate(order, 1):
    body = objects.get(img_num, b"")
    if b"DCTDecode" not in body:
        continue
    s = body.find(b"stream")
    if s == -1:
        continue
    s = body.find(b"\n", s) + 1
    e = body.rfind(b"endstream")
    jpeg = body[s:e].rstrip(b"\r\n")
    if not jpeg.startswith(b"\xff\xd8"):
        continue
    path = os.path.join(OUT, f"p{idx:03d}.jpg")
    with open(path, "wb") as fh:
        fh.write(jpeg)
    saved += 1

print(f"saved {saved} jpegs to {OUT}")
