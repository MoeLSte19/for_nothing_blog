<#
.SYNOPSIS
    Archive phone photos into 05-附件 with date-based names and print ready-to-paste Obsidian links.

.DESCRIPTION
    Run from the vault root (the folder containing 00-收集箱 and 05-附件).
    Reads images from the source folder, renames them to YYYYMMDD-topic-NN.ext,
    moves them into 05-附件/YYYY-MM/, then prints Markdown embed syntax and copies it to the clipboard.

.PARAMETER Topic
    Topic used in the file name, e.g. "leveling" or a Chinese topic string.

.PARAMETER Source
    Folder to read images from. Default: 00-收集箱

.PARAMETER Date
    Date stamp for file names, format yyyyMMdd. Default: today.

.PARAMETER Width
    Display width in the printed links. 0 means no width suffix.

.PARAMETER Keep
    Copy instead of move (originals stay in the source folder).

.EXAMPLE
    .\scripts\Import-Photos.ps1 -Topic "leveling"

.EXAMPLE
    .\scripts\Import-Photos.ps1 -Topic "math-limits" -Date 20260220 -Width 400
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Topic,

    [string]$Source = '00-收集箱',

    [string]$Date = (Get-Date -Format 'yyyyMMdd'),

    [int]$Width = 500,

    [switch]$Keep
)

$ErrorActionPreference = 'Stop'

# Force UTF-8 console output so Chinese file names and topics print correctly on Windows PowerShell 5.1
try {
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $OutputEncoding = New-Object System.Text.UTF8Encoding($false)
}
catch {
    Write-Verbose 'Could not switch console encoding to UTF-8.'
}

$VaultRoot = if ($PSScriptRoot) { Split-Path -Parent $PSScriptRoot } else { (Get-Location).Path }
$SourceDir = Join-Path $VaultRoot $Source

if (-not (Test-Path -LiteralPath $SourceDir)) {
    Write-Host "[X] Source folder not found: $SourceDir" -ForegroundColor Red
    Write-Host "    Run this script from the vault root, or pass -Source <folder>." -ForegroundColor Yellow
    exit 1
}

$Extensions = @('.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.heic', '.tif', '.tiff')

$Images = Get-ChildItem -LiteralPath $SourceDir -File |
Where-Object { $Extensions -contains $_.Extension.ToLower() } |
Sort-Object Name

if ($Images.Count -eq 0) {
    Write-Host "[!] No images found in: $Source" -ForegroundColor Yellow
    Write-Host "    Supported: $($Extensions -join ', ')"
    exit 0
}

if ($Date -notmatch '^\d{8}$') {
    Write-Host "[X] -Date must be 8 digits in yyyyMMdd form, got: $Date" -ForegroundColor Red
    exit 1
}

# Strip characters that are illegal in Windows file names
$SafeTopic = $Topic -replace '[\\/:*?"<>|\s]+', '_'
$TargetDir = Join-Path $VaultRoot (Join-Path '05-附件' ($Date.Substring(0, 4) + '-' + $Date.Substring(4, 2)))

if (-not (Test-Path -LiteralPath $TargetDir)) {
    New-Item -ItemType Directory -Path $TargetDir -Force | Out-Null
}

$Index = 0
$Links = foreach ($Image in $Images) {
    $Index++
    $Number = '{0:D2}' -f $Index
    $Ext = $Image.Extension.ToLower()
    $NewName = "$Date-$SafeTopic-$Number$Ext"
    $TargetPath = Join-Path $TargetDir $NewName

    # Never overwrite an existing attachment
    $Suffix = 1
    while (Test-Path -LiteralPath $TargetPath) {
        $NewName = "$Date-$SafeTopic-$Number" + "_$Suffix" + $Ext
        $TargetPath = Join-Path $TargetDir $NewName
        $Suffix++
    }

    if ($Keep) {
        Copy-Item -LiteralPath $Image.FullName -Destination $TargetPath
    }
    else {
        Move-Item -LiteralPath $Image.FullName -Destination $TargetPath
    }

    Write-Host ("  archived  {0}  ->  {1}" -f $Image.Name, $NewName) -ForegroundColor Green

    if ($Width -gt 0) { "![[$NewName|$Width]]" } else { "![[$NewName]]" }
}

Write-Host ''
Write-Host "Done. $($Images.Count) image(s) -> $TargetDir" -ForegroundColor Cyan
Write-Host 'Paste the following into your Obsidian note:' -ForegroundColor Cyan
Write-Host ('-' * 60)
$Links | ForEach-Object { Write-Host $_ }

try {
    ($Links -join "`r`n") | Set-Clipboard
    Write-Host ('-' * 60)
    Write-Host '[OK] Links copied to clipboard - just press Ctrl+V in Obsidian.' -ForegroundColor Green
}
catch {
    Write-Host ('-' * 60)
    Write-Host '(Clipboard unavailable - copy the links above manually.)' -ForegroundColor Yellow
}
