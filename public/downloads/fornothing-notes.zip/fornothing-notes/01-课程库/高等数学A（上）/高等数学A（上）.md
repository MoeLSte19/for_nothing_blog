---
type: 课程
course: 高等数学A（上）
subject: 学科平台
code: G13121001
credits: 4.5
grade: 一
term: 1
semester: 2026-2027-1
tags: [课程]
date: 2026-09-15
status: 进行中
---

# 高等数学A（上）

| 项目 | 内容 |
| --- | --- |
| 课程号 | `G13121001` |
| 学科分类 | 学科平台 |
| 学分 | 4.5 |
| 建议修读 | 大一 第1学期（2026-2027-1） |
| 教师 |  |
| 教室 / 时间 |  |
| 考核方式 |  |

## 🎯 这门课是什么

极限、导数、微分中值定理、不定积分与定积分。**大一最关键的一门课**，直接决定后面平差和大地测量能不能学懂。

## 📌 学习重点

- 

## 📖 参考资源

- 教材：
- 课件位置：`04-资料库/高等数学A（上）/`

## 🗂 课堂笔记

```dataview
TABLE WITHOUT ID
  file.link AS "笔记",
  chapter AS "章节",
  date AS "日期",
  status AS "状态"
FROM "01-课程库"
WHERE file.folder = this.file.folder AND file.name != this.file.name
SORT date ASC
```

## 🧠 本课关联知识点

```dataview
TABLE WITHOUT ID
  file.link AS "知识点",
  importance AS "重要度",
  status AS "掌握度"
FROM "02-知识库"
WHERE type = "知识点" AND course = this.course
SORT importance ASC, file.name ASC
```

## ❓ 疑问清单

- [ ] 

## 📝 作业

```dataview
TABLE WITHOUT ID file.link AS "作业", due AS "截止", status AS "状态"
FROM "01-课程库" OR "04-资料库"
WHERE type = "作业" AND course = this.course
SORT due ASC
```

## 📊 成绩记录

| 项目 | 日期 | 得分 | 满分 | 备注 |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
