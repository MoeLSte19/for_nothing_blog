---
type: 课程
course: C++面向对象程序设计
subject: 个性化发展
code: G25132031
credits: 2.0
grade: 二
term: 1
semester: 2027-2028-1
tags: [课程]
date: 2026-09-15
status: 未开始
---

# C++面向对象程序设计

| 项目 | 内容 |
| --- | --- |
| 课程号 | `G25132031` |
| 学科分类 | 个性化发展 |
| 学分 | 2.0 |
| 建议修读 | 大二 第1学期（2027-2028-1） |
| 教师 |  |
| 教室 / 时间 |  |
| 考核方式 |  |

## 🎯 这门课是什么

C++ 语法与面向对象思想，是测绘数据处理类软件的常见实现语言。

## 📌 学习重点

- 

## 📖 参考资源

- 教材：
- 课件位置：`04-资料库/C++面向对象程序设计/`

## 🗂 课堂笔记

```dataview
TABLE WITHOUT ID
  file.link AS "笔记",
  chapter AS "章节",
  date AS "日期",
  status AS "状态"
FROM "01-课程库"
WHERE file.folder = this.file.folder AND file.name != this.file.name
SORT date ASC
```

## 🧠 本课关联知识点

```dataview
TABLE WITHOUT ID
  file.link AS "知识点",
  importance AS "重要度",
  status AS "掌握度"
FROM "02-知识库"
WHERE type = "知识点" AND course = this.course
SORT importance ASC, file.name ASC
```

## ❓ 疑问清单

- [ ] 

## 📝 作业

```dataview
TABLE WITHOUT ID file.link AS "作业", due AS "截止", status AS "状态"
FROM "01-课程库" OR "04-资料库"
WHERE type = "作业" AND course = this.course
SORT due ASC
```

## 📊 成绩记录

| 项目 | 日期 | 得分 | 满分 | 备注 |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
