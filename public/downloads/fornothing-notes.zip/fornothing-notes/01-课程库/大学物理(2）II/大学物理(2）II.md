---
type: 课程
course: 大学物理(2）II
subject: 学科平台
code: G19121076
credits: 3.0
grade: 二
term: 1
semester: 2027-2028-1
tags: [课程]
date: 2026-09-15
status: 未开始
---

# 大学物理(2）II

| 项目 | 内容 |
| --- | --- |
| 课程号 | `G19121076` |
| 学科分类 | 学科平台 |
| 学分 | 3.0 |
| 建议修读 | 大二 第1学期（2027-2028-1） |
| 教师 |  |
| 教室 / 时间 |  |
| 考核方式 |  |

## 🎯 这门课是什么

电磁学与光学。波动、干涉等概念与 GNSS 信号、遥感原理相关。

## 📌 学习重点

- 

## 📖 参考资源

- 教材：
- 课件位置：`04-资料库/大学物理(2）II/`

## 🗂 课堂笔记

```dataview
TABLE WITHOUT ID
  file.link AS "笔记",
  chapter AS "章节",
  date AS "日期",
  status AS "状态"
FROM "01-课程库"
WHERE file.folder = this.file.folder AND file.name != this.file.name
SORT date ASC
```

## 🧠 本课关联知识点

```dataview
TABLE WITHOUT ID
  file.link AS "知识点",
  importance AS "重要度",
  status AS "掌握度"
FROM "02-知识库"
WHERE type = "知识点" AND course = this.course
SORT importance ASC, file.name ASC
```

## ❓ 疑问清单

- [ ] 

## 📝 作业

```dataview
TABLE WITHOUT ID file.link AS "作业", due AS "截止", status AS "状态"
FROM "01-课程库" OR "04-资料库"
WHERE type = "作业" AND course = this.course
SORT due ASC
```

## 📊 成绩记录

| 项目 | 日期 | 得分 | 满分 | 备注 |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |
